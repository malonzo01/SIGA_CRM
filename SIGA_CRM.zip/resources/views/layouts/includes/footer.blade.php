<a href="#" class="back-to-top d-flex align-items-center justify-content-center"><i class="fas fa-chevron-up"></i></a>

<footer id="footer" class="footer">
  <div class="copyright">
    &copy; Copyright <strong><span>SIGA</span></strong>. Todos los derechos reservados
  </div>
</footer>