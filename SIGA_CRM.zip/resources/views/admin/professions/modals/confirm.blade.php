<!-- Modal -->
<div class="modal fade" id="confirmModal" tabindex="-1" aria-labelledby="confirmModal" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-body">
          <p>Deseas eliminar esta Profesión/Servicio?</p>
      </div>
      <div class="modal-footer">
        <button type="button" id="ok_button" class="btn btn-danger">Si</button>
        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">No</button>
      </div>
    </div>
  </div>
</div>